package org.sisma.dao;

import java.util.List;

import org.sisma.models.Siswa;


public interface SiswaDao {

    List <Siswa> listSiswa();
	List<Siswa> listSiswaByIdKelas(Integer idKelas);
    Siswa saveOrUpdate(Siswa siswa);
    Siswa getIdSiswa(Integer id);
    void hapusSiswa (Integer id);	
	List<Siswa> getAllRequestByStatus(String status); 
	
}


