/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.akademik.model.MataKuliah;

/**
 *
 * @author Helkia
 */
public class MataKuliahDao 
{
     private Connection connection;

    public MataKuliahDao(Connection connection) {
        this.connection = connection;
    }
    
    public void addMK(MataKuliah MK)
    {
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into matakuliah(idMK,namaMK,sks) values (?,?,?)");
            
            preparedStatement.setString(1, MK.getIdMK());
            preparedStatement.setString(2, MK.getNamaMK());
            preparedStatement.setInt(3, MK.getSks());
            
        }catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
    public void updateMK(MataKuliah MK)
    {
        
    }
    
    public void deleteMK(String id)
    {
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from matakuliah where idMK = ?");
            preparedStatement.setString(1, id);
            preparedStatement.executeQuery();
            
        }catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
}
