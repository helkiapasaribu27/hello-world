/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.akademik.model.Kelas;
import org.akademik.model.Mahasiswa;
import org.akademik.model.Perkuliahan;

/**
 *
 * @author Helkia
 */
public class PerkuliahanDao 
{
    private Connection connection;

    public PerkuliahanDao(Connection connection) {
        this.connection = connection;
    }
    
    public void addPerkuliahan(Perkuliahan P)
    {
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into perkuliahan(nim,idMK,nilai) values (?,?,?)");
            
            preparedStatement.setString(1, P.getNim());
            preparedStatement.setString(2, P.getIdMK());
            preparedStatement.setDouble(3, P.getNilai());
            
        }catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
    public Mahasiswa getMahasiswaNilaiTertinggiByMK(String idMK)
    {
        Mahasiswa a = null;
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from mahasiswa a,perkuliahan b on a.nim=b.nim where b.nilai=(select max(nilai) from perkuliahan) and id = ?");
            preparedStatement.setString(1, idMK);
            
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next())
            {
                String nim1 = rs.getString(1);
                String nama = rs.getString(2);
                double ip = rs.getFloat(3);
                int idKelas = rs.getInt(4);
                String namaKelas = rs.getString(6);
                String dosenWali = rs.getString(7);
                a = new Mahasiswa(nim1, nama, ip, new Kelas(idKelas, namaKelas, dosenWali));
            }
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return a;
    }
    
    
}
