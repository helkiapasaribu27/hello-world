/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.akademik.model.Kelas;
import org.akademik.model.Mahasiswa;
import org.akademik.util.DBUtil;

/**
 *
 * @author Helkia
 */
public class KelasDao {

    private Connection connection;

    public KelasDao() {
        connection = DBUtil.getConnection();
    }

    public void addKelas(Kelas kelas) {
        //tugas.. dikerjakan
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into kelas(id, nama,dosenWali) values(?,?,?)");
            preparedStatement.setInt(1, kelas.getId());
            preparedStatement.setString(2, kelas.getNama());
            preparedStatement.setString(3, kelas.getDosenWali());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteKelas(int idKelas) {
        //tugas.. dikerjakan
         try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from kelas where id=?");
            preparedStatement.setInt(1,idKelas);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateKelas(Kelas kelas) {
        //tugas.. dikerjakan
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update kelas set id=?, nama=?, dosenWali=? where id=?");
            preparedStatement.setInt(1, kelas.getId());
            preparedStatement.setString(2, kelas.getNama());
            preparedStatement.setString(3, kelas.getDosenWali());
            preparedStatement.setInt(4, kelas.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Mahasiswa> getAllMahasiswaPadaSatuKelas(int idKelas) {
        List<Mahasiswa> mahasiswas = new ArrayList<>();
        //tugas.. dikerjakan
        return mahasiswas;
    }

    public List<Kelas> getAllKelas() {
        List<Kelas> kelass = new ArrayList<>();
        //tugas.. dikerjakan
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select b.id, b.nama,b.dosenWali from mahasiswa a, kelas b where a.idKelas = b.id" );
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nama = rs.getString(2);
                
                String dosenWali = rs.getString(3);
                Kelas k = new Kelas(id, nama,dosenWali);
                kelass.add(k);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kelass;
    }
}
