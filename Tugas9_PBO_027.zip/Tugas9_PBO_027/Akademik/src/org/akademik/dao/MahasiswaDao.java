/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.akademik.model.Kelas;
import org.akademik.model.Mahasiswa;
import org.akademik.util.DBUtil;

/**
 *
 * @author Helkia
 */

    public class MahasiswaDao {

    private Connection connection;

    public MahasiswaDao() {
        connection = DBUtil.getConnection();
    }

    public void addMahasiswa(Mahasiswa mahasiswa) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into mahasiswa(nim, nama, indeksPrestasi, idKelas) values( ?,  ?,  ?,  ?)" );
            preparedStatement.setString(1, mahasiswa.getNim());
            preparedStatement.setString(2, mahasiswa.getNama());
            preparedStatement.setDouble(3, mahasiswa.getIndekPrestasi());
            preparedStatement.setInt(4, mahasiswa.getKelas().getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMahasiswa(String nim) {
        //tugas.. dikerjakan
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from mahasiswa where nim=?");
            preparedStatement.setString(1,nim);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMahasiswa(Mahasiswa mahasiswa) {
        //tugas.. dikerjakan
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update mahasiswa set nim=?, nama=?, indeksPrestasi=?, idKelas=? where nim=?");
            preparedStatement.setString(1, mahasiswa.getNim());
            preparedStatement.setString(2, mahasiswa.getNama());
            preparedStatement.setDouble(3, mahasiswa.getIndekPrestasi());
            preparedStatement.setInt(4, mahasiswa.getKelas().getId());
            preparedStatement.setString(5, mahasiswa.getNim());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Mahasiswa> getAllMahasiswa() {
        List<Mahasiswa> mahasiswas = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select a.nim,a.nama,a.indeksPrestasi,a.idKelas,b.nama,b.dosenWali from mahasiswa a, kelas b where a.idKelas = b.id" );
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String nim = rs.getString(1);
                String nama = rs.getString(2);
                double ip = rs.getDouble(3);
                int idKelas = rs.getInt(4);
                String namaKelas = rs.getString(5);
                String dosenWali = rs.getString(6);
                Mahasiswa m = new Mahasiswa(nim, nama, ip, new Kelas(idKelas,namaKelas,dosenWali));
                mahasiswas.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mahasiswas;
    }

    public Mahasiswa getMahasiswaByNim(String nim) {
        Mahasiswa mahasiswa = new Mahasiswa();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select a.nim,a.nama,a.indeksPrestasi,a.idKelas,b.nama,b.dosenWali from mahasiswa a, kelas b where a.idKelas = b.id" );
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String tmpNim = rs.getString(1);
                String nama = rs.getString(2);
                double ip = rs.getDouble(3);

                int idKelas = rs.getInt(4);
                String namaKelas = rs.getString(5);
                String dosenWali = rs.getString(6);
                if(nim.equalsIgnoreCase(tmpNim))
                {
                    Mahasiswa m = new Mahasiswa(tmpNim, nama, ip, new Kelas(idKelas,namaKelas,dosenWali));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mahasiswa;
    }

}

    

