/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.model;

/**
 *
 * @author Helkia
 */
public class MataKuliah 
{
     private String idMK;
    private String namaMK;
    private int sks;

    public MataKuliah() {
    }

    public MataKuliah(String idMK, String namaMK, int sks) {
        this.idMK = idMK;
        this.namaMK = namaMK;
        this.sks = sks;
    }

    public String getIdMK() {
        return idMK;
    }

    public void setIdMK(String idMK) {
        this.idMK = idMK;
    }

    public String getNamaMK() {
        return namaMK;
    }

    public void setNamaMK(String namaMK) {
        this.namaMK = namaMK;
    }

    public int getSks() {
        return sks;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }
    
    
}

    

