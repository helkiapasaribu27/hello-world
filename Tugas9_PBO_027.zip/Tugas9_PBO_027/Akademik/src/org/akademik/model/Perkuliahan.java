/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.model;

/**
 *
 * @author Helkia
 */
public class Perkuliahan 
{
    private String nim;
    private String idMK;
    private double nilai;

    public Perkuliahan() {
    }

    public Perkuliahan(String nim, String idMK, double nilai) {
        this.nim = nim;
        this.idMK = idMK;
        this.nilai = nilai;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getIdMK() {
        return idMK;
    }

    public void setIdMK(String idMK) {
        this.idMK = idMK;
    }

    public double getNilai() {
        return nilai;
    }

    public void setNilai(double nilai) {
        this.nilai = nilai;
    }
    
    
    
}
