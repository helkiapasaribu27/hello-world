/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.akademik.model;

/**
 *
 * @author Helkia
 */
public class Kelas 
{
     private int id;
    private String nama;
    private String dosenWali;

    public Kelas() {
    }

    public Kelas(int id, String nama,String dosenWali) {
        this.id = id;
        this.nama = nama;
        this.dosenWali= dosenWali;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDosenWali() {
        return dosenWali;
    }

    public void setDosenWali(String dosenWali) {
        this.dosenWali = dosenWali;
    }
}

