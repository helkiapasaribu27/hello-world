/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mahasiswa.driver;

import java.sql.SQLException;
import java.util.List;
import org.akademik.dao.KelasDao;
import org.akademik.dao.MahasiswaDao;
import org.akademik.model.Kelas;
import org.akademik.model.Mahasiswa;

/**
 *
 * @author Helkia
 */
public class Driver 
{
    public static void main(String[] args) throws SQLException
    {
        Mahasiswa mahasiswa;
        Kelas kelas;
        
        MahasiswaDao mahasiswaDao = new MahasiswaDao();
        KelasDao kelasDao = new KelasDao();
        mahasiswa = new Mahasiswa("12", "dapot", 3.5, new Kelas(1, "Informatika", "marroha"));
        mahasiswaDao.addMahasiswa(mahasiswa);
        mahasiswa = new Mahasiswa("13", "dapotwati", 3.7, new Kelas(2, "Informasi", "dapit"));
        mahasiswaDao.addMahasiswa(mahasiswa);
        kelas = new Kelas(1, "Iformatika", "dapot");
        kelasDao.addKelas(kelas);
        kelas = new Kelas(2, "Informasi", "dapotwati");
        kelasDao.addKelas(kelas);
        mahasiswaDao.deleteMahasiswa("12");
        kelasDao.deleteKelas(1);
        
        mahasiswa = new Mahasiswa("13", "dara", 4.0, new Kelas(1, "Informasi", "dapit"));
        mahasiswaDao.updateMahasiswa(mahasiswa);
        kelas = new Kelas(2, "MR", "wela");
        kelasDao.updateKelas(kelas);
        
        List<Mahasiswa> ms = mahasiswaDao.getAllMahasiswa();
        for (Mahasiswa m : ms) {
            System.out.println(m);
        }
    }
}
