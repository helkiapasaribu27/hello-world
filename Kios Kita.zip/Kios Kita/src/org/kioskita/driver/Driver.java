package org.kioskita.driver;

import static javafx.application.Application.launch;


public class Driver 
{
    public static void main(String[] args) 
    {
        launch(Koperasi.class, args);
        
    }
}
