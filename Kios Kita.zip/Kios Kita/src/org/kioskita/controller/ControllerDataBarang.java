package org.kioskita.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import org.kioskita.dao.BarangDao;
import org.kioskita.dao.impl.BarangDaoImplHibernate;
import org.kioskita.model.Barang;

/**
 *
 * @author rantyana
 */
public class ControllerDataBarang implements Initializable {

    @FXML
    private TextField kodeBarangTF;
    @FXML
    private TextField namaBarangTF;
    @FXML
    private TextField hargaBarangTF;
    @FXML
    private TextField stokBarangTF;
    @FXML
    private TextField cariBarangTF;
  
    private BarangDao bDao;
    @FXML
    TableView<Barang> barangTV;          
    @FXML
    TableColumn<Barang, String> kodeBarangTV;    
    @FXML
    TableColumn<Barang, String> namaBarangTV;
    @FXML
    TableColumn<Barang, Double> hargaSatuanTV;
    @FXML
    TableColumn<Barang, Integer> stokTV;

    ObservableList<Barang> dataBarang;

    @FXML
    private MenuItem menuJual;
    private static String kodeBarang;
    private static String namaBarang;
    private static Double hargaSatuan;
    private static int stokBarang;

    public ControllerDataBarang() {
        bDao = new BarangDaoImplHibernate();
        barangTV = new TableView<>();

    }

    @FXML
    public void menuPenjualan(ActionEvent event) {
        System.out.println("no");
        try {
            ((Node) (event.getSource())).getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/kioskita/view/ViewDataPenjualan.fxml"));
            Parent root1 = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(ControllerDataBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void menuPembelian(ActionEvent event) throws IOException {
        try {
            ((Node) (event.getSource())).getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/kioskita/view/ViewDataPembelian.fxml"));
            Parent root1 = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (IOException ioe) {

        }
    }

    @FXML
    public void menuItemLPenjualan(ActionEvent event) throws IOException {
        try {
            ((Node) (event.getSource())).getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/kioskita/view/viewLaporanPenjualan.fxml"));
            Parent root1 = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (IOException ioe) {

        }
    }

    @FXML
    public void menuItemLPembelian(ActionEvent event) throws IOException {
        try {
            ((Node) (event.getSource())).getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/kioskita/view/viewLaporanPembelian.fxml"));
            Parent root1 = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (IOException ioe) {

        }
    }
    
    @FXML
    public void menuLogout(ActionEvent event) throws IOException{
        System.out.println("dipanggil");
        int confirm = JOptionPane.showConfirmDialog(null, "Anda Yakin ingin Logout?");
        if (confirm == JOptionPane.OK_OPTION) {
            System.out.println("dipanggilnya");
            try {
                ((Node) (event.getSource())).getScene().getWindow().hide();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/org/kioskita/view/ViewLogin.fxml"));
                Parent root1 = fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
            } catch (IOException ioe) {

            }
        }
    }
    private void inisialisiAwalInputan() {
        kodeBarangTF.setText("");
        namaBarangTF.setText("");
        hargaBarangTF.setText("");
        stokBarangTF.setText("");

    }
    
    public void loadData() {
        List<Barang> barangs = bDao.getAllBarang();
        for (Barang m : barangs) {
            System.out.println("nama :" + m.getKodeBarang());
        }
        dataBarang = FXCollections.observableArrayList(barangs);
        kodeBarangTV.setCellValueFactory(new PropertyValueFactory<Barang, String>("kodeBarang"));
        namaBarangTV.setCellValueFactory(new PropertyValueFactory<Barang, String>("namaBarang"));
        hargaSatuanTV.setCellValueFactory(new PropertyValueFactory<Barang, Double>("hargaSatuan"));
        stokTV.setCellValueFactory(new PropertyValueFactory<Barang, Integer>("stokBarang"));
        barangTV.setItems(dataBarang);

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) //Perintah untuk memampukan program "Apa yang perlu ditampikan setelah diRun"
    {
        loadData();
    }
   
    public void loadTabelBerdasarkanKodeBarang() {
        String kode = cariBarangTF.getText();
        boolean adaKode = false;
        for (Barang barang : bDao.getAllBarang()) {
            if (kode.equalsIgnoreCase(barang.getKodeBarang())) {
                adaKode = true;
            }
        }
        if (adaKode) {
            dataBarang = FXCollections.observableArrayList(bDao.cariDataBarang(kode));
            kodeBarangTV.setCellValueFactory(new PropertyValueFactory<Barang, String>("kodeBarang"));
            namaBarangTV.setCellValueFactory(new PropertyValueFactory<Barang, String>("namaBarang"));
            hargaSatuanTV.setCellValueFactory(new PropertyValueFactory<Barang, Double>("hargaSatuan"));
            stokTV.setCellValueFactory(new PropertyValueFactory<Barang, Integer>("stokBarang"));
            barangTV.setItems(dataBarang);
        } else {
            JOptionPane.showMessageDialog(null, "Kode " + kode + " tidak ada");
        }

    }

    @FXML
    public void cariBarang(ActionEvent event) {
        loadTabelBerdasarkanKodeBarang();

    }

}
