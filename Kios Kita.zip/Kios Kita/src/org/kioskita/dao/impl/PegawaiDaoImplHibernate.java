package org.kioskita.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.kioskita.dao.PegawaiDao;
import org.kioskita.model.Barang;
import org.kioskita.model.Pegawai;
import org.kioskita.util.HibernateUtil;


public class PegawaiDaoImplHibernate implements PegawaiDao {

    @Override
    public void savePegawai(Pegawai pegawai) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pegawai);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Pegawai> getAllPegawai() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pegawai> pegawais = session.createCriteria(Pegawai.class).list();
        session.getTransaction().commit();
        for (Pegawai m : pegawais) {
            System.out.println("nama :" + m.getNama());
        }
        return pegawais;
    }

}
