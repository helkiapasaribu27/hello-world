package org.kioskita.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.kioskita.dao.MenejerDao;
import org.kioskita.model.Menejer;
import org.kioskita.util.HibernateUtil;


public class MenejerDaoImplHibernate implements MenejerDao
{

   @Override
    public void saveMenejer(Menejer menejer) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(menejer);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Menejer> getAllMenejer() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Menejer> menejers = session.createCriteria(Menejer.class).list();
        session.getTransaction().commit();
        for (Menejer m : menejers) {
            System.out.println("nama :" + m.getNama());
        }
        return menejers;
    }
}
