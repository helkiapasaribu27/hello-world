package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.LaporanPenjualan;
import org.kioskita.model.Penjualan;


public interface LaporanPenjualanDao 
{
    public void cariLaporanPenjualan(String tanggal);
    public List<LaporanPenjualan> getAllLaporanPenjualan(String tanggal);
    public void saveDataLaporanPenjualan(LaporanPenjualan lapJual);
    public List<Penjualan> getAllLaporan();
}
