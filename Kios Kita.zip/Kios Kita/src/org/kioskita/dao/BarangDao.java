package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.Barang;


public interface BarangDao 
{
    public void saveDataBarang(String kodeBarang, String namaBarang, double hargaSatuan, int stokBarang);
    public Barang cariDataBarang(String kodeBarang);
    public List<Barang> getAllBarang();
    public void updateDataBarang(Barang b);
    public void updateJumlahDataBarang(String kodeBarang,int stokBarang);
    public void deleteDataBarang(Barang b);
    public int getStockBarang(String kodeBarang);
}
