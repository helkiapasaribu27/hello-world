package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.Pegawai;

/**
 *
 * @author  helkiapasaribu
 */
public interface PegawaiDao 
{
    public void savePegawai(Pegawai pegawai);
    public List<Pegawai> getAllPegawai();
}
