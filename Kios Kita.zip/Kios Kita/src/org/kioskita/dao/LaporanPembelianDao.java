package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.LaporanPembelian;
import org.kioskita.model.Pembelian;


public interface LaporanPembelianDao {

    public void cariLaporanPembelian(String tanggal);

    public List<LaporanPembelian> getAllLaporanPembelian(String tanggal);

    public void saveDataLaporanPembelian(LaporanPembelian lapBeli);

    public List<Pembelian> getAllLaporan();

}
