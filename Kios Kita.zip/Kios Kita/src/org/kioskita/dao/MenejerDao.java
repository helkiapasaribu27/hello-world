package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.Menejer;

/**
 *
 * @author  helkiapasaribu
 */
public interface MenejerDao 
{
      public void saveMenejer(Menejer menejer);
      public List<Menejer> getAllMenejer();
}
