package org.kioskita.dao;

import java.util.List;
import org.kioskita.model.Pembelian;

/**
 *
 * @author  helkiapasaribu
 */
public interface PembelianDao {

    public void saveDBDataPembelianBarang(Pembelian p);

    public List<Pembelian> getAllPembelian();
    public List<Pembelian> getAllPembelianBerdasarkanTanggal(String tanggal);

    public void deleteDataPembelian(Pembelian p);

    public void updateDataPembelian(Pembelian p);
}
