/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pdam.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.pdam.dao.AkunDao;
import org.pdam.model.Akun;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class AkunDaoImplHibernate implements AkunDao
{

    @Override
    public List<Akun> getAllAkun()
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Akun> akuns = session.createCriteria(Akun.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        
        return akuns;
    }

    @Override
    public Akun getAkunAktif() 
    {
        List<Akun> akuns = getAllAkun();
        Akun akun = null;
        for(Akun a : akuns)
        {
            if(a.getId()==1)
            {
                akun = a;
            }
        }
        return akun;
    }

    @Override
    public Akun getAkunByUsername(String username) 
    {
        List<Akun> akuns = getAllAkun();
        Akun gg = null;
        for(Akun a : akuns)
        {
            if(a.getUsername().equalsIgnoreCase(username))
            {
                gg = a;
            }
            
        }
        return gg;
    }

    @Override
    public void saveDataAkun(Akun akun) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void updateIDAkun(Akun akun)
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin(); 
        session.update("id",akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        
    }

    @Override
    public void updatePasswordAkun(Akun akun) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin(); 
        session.update("password",akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
    
}
