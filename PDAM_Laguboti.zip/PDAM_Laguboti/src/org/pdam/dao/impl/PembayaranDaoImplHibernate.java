package org.pdam.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.pdam.dao.AkunDao;
import org.pdam.dao.PegawaiDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.PembayaranDao;
import org.pdam.model.Akun;
import org.pdam.model.Pegawai;
import org.pdam.model.Pelanggan;
import org.pdam.model.Pembayaran;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class PembayaranDaoImplHibernate implements PembayaranDao
{

    @Override
    public void savePembayaran(Pembayaran pembayaran) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pembayaran);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Pembayaran> getAllBelumVerfikasi(int idPelanggan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pembayaran> pembayarans = session.createCriteria(Pembayaran.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        AkunDao aDao = new AkunDaoImplHibernate();
        PelangganDao pelDao = new PelangganDaoImplHibernate();
        Pelanggan pel = pelDao.getPelangganByUsername(aDao.getAkunAktif().getUsername());
        List<Pembayaran> ps = new ArrayList<>();
        for(Pembayaran p : pembayarans)
        {
            if(p.getIdPelanggan()==pel.getIdPelanggan())
            {
                if(p.getStatus() == 0)
                {
                    ps.add(p);
                }
            }
                
        }
        return ps;
    }

    @Override
    public List<Pembayaran> getAllSudahVerfikasi(int idPelanggan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pembayaran> pembayarans = session.createCriteria(Pembayaran.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        List<Pembayaran> ps = new ArrayList<>();
        for(Pembayaran p : pembayarans)
        {
            if(p.getStatus() == 1)
            {
                ps.add(p);
            }
        }
        return ps;
    }

    @Override
    public Pembayaran getPembayaranByID(int idPembayaran)
    {
        PegawaiDao pegDao = new PegawaiDaoImplHibernate();
        AkunDao aDao = new AkunDaoImplHibernate();
        Pegawai pegawai = pegDao.getPegawaiByUsername(aDao.getAkunAktif().getUsername());
        List<Pembayaran> p = getAllBelumVerfikasi(pegawai.getIdPegawai());
        Pembayaran pembayaran = null;
        for(Pembayaran peg : p)
        {
            if(peg.getIdPembayaran() == idPembayaran)
            {
                pembayaran = peg;
            }
        }
        return pembayaran;
    }

    @Override
    public List<Pembayaran> getAllBelumVerifikasiByRegional(int idRegional) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pembayaran> pembayarans = session.createCriteria(Pembayaran.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        List<Pembayaran> ps = new ArrayList<>();
        for(Pembayaran p : pembayarans)
        {
            if(p.getRegional()==idRegional)
            {
                if(p.getStatus()==0)
                {
                    ps.add(p);
                }
                
            }
        }
        return ps;
    }

    @Override
    public void updateStatusPembayaran(Pembayaran pembayaran) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin(); 
        session.update("status",pembayaran);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
    
}
