package org.pdam.dao.impl;

import org.hibernate.Session;
import org.pdam.dao.JabatanDao;
import org.pdam.model.Jabatan;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class JabatanDaoImplHibernate implements JabatanDao
{

    @Override
    public void saveJabatan(Jabatan jabatan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(jabatan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Jabatan getJabatanByID(int idJabatan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Jabatan j = (Jabatan)session.get(Jabatan.class,idJabatan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return j;
    }

}
