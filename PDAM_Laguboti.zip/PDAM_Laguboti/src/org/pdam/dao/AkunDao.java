/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pdam.dao;

import java.util.List;
import org.pdam.model.Akun;

/**
 *
 * @author helkia
 */
public interface AkunDao 
{
    public List<Akun> getAllAkun();
    public Akun getAkunAktif();
    public Akun getAkunByUsername(String username);
    public void saveDataAkun(Akun akun);
    public void updateIDAkun(Akun akun);
    public void updatePasswordAkun(Akun akun);
}
