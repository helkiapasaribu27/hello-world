package org.pdam.dao;

import org.pdam.model.Regional;

/**
 *
 * @author helkia
 */
public interface RegionalDao 
{
    public void saveRegional(Regional regional);
    public void getAllAnggotaRegionalByID(int idRegional);
}
