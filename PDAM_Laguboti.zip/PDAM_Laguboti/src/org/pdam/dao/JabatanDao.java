package org.pdam.dao;

import org.pdam.model.Jabatan;

/**
 *
 * @author helkia
 */
public interface JabatanDao 
{
    public void saveJabatan(Jabatan jabatan);
    public Jabatan getJabatanByID(int idJabatan);
}
