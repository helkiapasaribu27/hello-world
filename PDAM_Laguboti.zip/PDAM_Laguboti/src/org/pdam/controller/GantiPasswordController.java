package org.pdam.controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.PegawaiDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.dao.impl.PegawaiDaoImplHibernate;
import org.pdam.dao.impl.PelangganDaoImplHibernate;
import org.pdam.model.Akun;
import org.pdam.model.Pegawai;
import org.pdam.model.Pelanggan;

public class GantiPasswordController 
{
    @FXML
    private Label invalidPasswordLamaLB;
    
    @FXML
    private Label berhasilLB;
    
    @FXML
    private TextField PassLamaTF;

    @FXML
    private TextField PassBaruTF;

    @FXML
    private TextField PassBaruTF1;

    private AkunDao aDao;
    private PelangganDao pelDao;
    private PegawaiDao pegDao;
    
    public GantiPasswordController() 
    {
        pelDao = new PelangganDaoImplHibernate();
        pegDao = new PegawaiDaoImplHibernate();
        aDao = new AkunDaoImplHibernate();
    }
    
    @FXML
    void gantiBT(ActionEvent event) 
    {
        String passLama = PassLamaTF.getText();
        String passBaru = PassBaruTF.getText();
        String passBaru1 = PassBaruTF1.getText();
        
        Akun a = aDao.getAkunAktif();
        
        if(passLama.equalsIgnoreCase(a.getPassword()))
        {
            if(passBaru.equalsIgnoreCase(passBaru1))
            {
                if(a.getRole().equalsIgnoreCase("pelanggan"))
                {
                    a.setPassword(passBaru);
                    Pelanggan pel = pelDao.getPelangganByUsername(a.getUsername());
                    pel.setPassword(passBaru);
                    aDao.updatePasswordAkun(a);
                    pelDao.updatePasswordAkun(pel);
                    invalidPasswordLamaLB.setVisible(false);
                    berhasilLB.setVisible(true);    
                }else if(a.getRole().equalsIgnoreCase("pegawai"))
                {
                    a.setPassword(passBaru);
                    Pegawai peg = pegDao.getPegawaiByUsername(a.getUsername());
                    peg.setPassword(passBaru);
                    aDao.updatePasswordAkun(a);
                    pegDao.updatePasswordAkun(peg);
                    invalidPasswordLamaLB.setVisible(false);
                    berhasilLB.setVisible(true);    
                }
            }
        }
        else
        {
            invalidPasswordLamaLB.setVisible(true);
        }
        
    }

    @FXML
    void backBT(ActionEvent event) throws IOException 
    {
        Akun a = aDao.getAkunAktif();
        if(a.getRole().equalsIgnoreCase("pelanggan"))
        {
            ((Node)(event.getSource())).getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/AkunPelanggan.fxml"));
            Scene scene = new Scene(parent,600,500);
            stage.setScene(scene);
            stage.show();
        }
        else if(a.getRole().equalsIgnoreCase("pegawai"))
        {
            ((Node)(event.getSource())).getScene().getWindow().hide();Stage stage = new Stage();
            Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/AkunPegawai.fxml"));
            Scene scene = new Scene(parent,600,500);
            stage.setScene(scene);
            stage.show();
        }
    }
    
    @FXML
    void logoutBT(ActionEvent event) throws IOException 
    {
        Akun a = aDao.getAkunAktif();
        a.setId(0);
        aDao.updateIDAkun(a);
        System.out.println("akhir "+a.getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }
}
