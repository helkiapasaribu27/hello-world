package org.pdam.controller;

import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.model.Akun;

public class LoginController
{

    @FXML
    private TextField usernameTF;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private Label invalidLB;

    private AkunDao aDao;

    public LoginController() 
    {
        aDao = new AkunDaoImplHibernate();
    }
    
    @FXML
    void loginB(ActionEvent event) throws IOException 
    {
        String username = usernameTF.getText();
        String password = passwordTF.getText();
        List<Akun> akuns = aDao.getAllAkun();
        
        for(Akun a : akuns)
        {
            if(username.matches(a.getUsername()))
            {
                if(password.matches(a.getPassword()))
                {
                    if(a.getRole().equalsIgnoreCase("pelanggan"))
                    {
                        ((Node)(event.getSource())).getScene().getWindow().hide();
                        System.out.println(a.getUsername());
                        a.setId(1);
                        aDao.updateIDAkun(a);
                        System.out.println(a.getId());
//                        System.out.println(aDao.getUsernameAkunAktif());
                        Akun akun = aDao.getAkunAktif();
                        System.out.println(akun.getUsername());
                        Stage stage = new Stage();
                        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Pembayaran.fxml"));
                        Scene scene = new Scene(parent,600,500);
                        stage.setScene(scene);
                        stage.show();
                    }
                    else if(a.getRole().equalsIgnoreCase("pegawai"))
                    {
                        ((Node)(event.getSource())).getScene().getWindow().hide();
                        System.out.println("Ini pegawai");
                        a.setId(1);
                        aDao.updateIDAkun(a);
                        Stage stage = new Stage();
                        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Verifikasi.fxml"));
                        Scene scene = new Scene(parent,600,500);
                        stage.setScene(scene);
                        stage.show();
                    }
                    else if(a.getRole().equalsIgnoreCase("admin"))
                    {
                        ((Node)(event.getSource())).getScene().getWindow().hide();
                        System.out.println("Ini admin");
                        a.setId(1);
                        aDao.updateIDAkun(a);
                        Stage stage = new Stage();
                        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/UnderConstruction.fxml"));
                        Scene scene = new Scene(parent,600,500);
                        stage.setScene(scene);
                        stage.show();
                    }
                }        
            }
        }
        invalidLB.setVisible(true);
    }

    
}
