package org.pdam.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.JabatanDao;
import org.pdam.dao.PegawaiDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.dao.impl.JabatanDaoImplHibernate;
import org.pdam.dao.impl.PegawaiDaoImplHibernate;
import org.pdam.dao.impl.PelangganDaoImplHibernate;
import org.pdam.model.Akun;
import org.pdam.model.Pegawai;
import org.pdam.model.Pelanggan;

public class AkunPegawaiController implements Initializable
{

    @FXML
    private Label idLB;

    @FXML
    private Label usernameLB;

    @FXML
    private Label namaLB;

    @FXML
    private Label alamatLB;

    @FXML
    private Label tahunLB;

    @FXML
    private Label teleponLB;

    @FXML
    private Label idJabatanLB;

    @FXML
    private Label namaJabatanLB;

    private PelangganDao pelDao;
    private AkunDao aDao;
    private Akun akunAktif;
    private PegawaiDao pegDao;
    private JabatanDao jabatanDao;
    
    public AkunPegawaiController() 
    {
        pegDao = new PegawaiDaoImplHibernate();
        pelDao = new PelangganDaoImplHibernate();
        aDao = new AkunDaoImplHibernate();
        akunAktif = aDao.getAkunAktif();
        jabatanDao = new JabatanDaoImplHibernate();
    }
    
    @FXML
    void backBT(ActionEvent event) throws IOException 
    {
        ((Node)(event.getSource())).getScene().getWindow().hide();Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Verifikasi.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void gantiPasswordBT(ActionEvent event) throws IOException
    {
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/GantiPassword.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void logoutBT(ActionEvent event) throws IOException
    {
        System.out.println("awal "+akunAktif.getId());
        akunAktif.setId(0);
        aDao.updateIDAkun(akunAktif);
        System.out.println("akhir "+akunAktif.getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }

    public void loadData()
    {
        Pegawai p = pegDao.getPegawaiByUsername(akunAktif.getUsername());
        idLB.setText(Integer.toString(p.getIdPegawai()));
        usernameLB.setText(p.getUsername());
        namaLB.setText(p.getNamaPegawai());
        alamatLB.setText(p.getAlamat());
        teleponLB.setText(Integer.toString(p.getNoTelepon()));
        tahunLB.setText(Integer.toString(p.getTahunMasuk()));
        idJabatanLB.setText(Integer.toString(p.getIdJabatan()));
        namaJabatanLB.setText(jabatanDao.getJabatanByID(p.getIdJabatan()).getNama());
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) 
    {
        loadData();
    }

}
