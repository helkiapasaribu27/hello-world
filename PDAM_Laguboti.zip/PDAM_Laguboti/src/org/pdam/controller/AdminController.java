package org.pdam.controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.model.Akun;


public class AdminController
{

    private AkunDao aDao;

    public AdminController() 
    {
        aDao = new AkunDaoImplHibernate();
    }
    
    @FXML
    void backBT(ActionEvent event) throws IOException
    {
        Akun a = aDao.getAkunAktif();
        a.setId(0);
        aDao.updateIDAkun(a);
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }
    
}
