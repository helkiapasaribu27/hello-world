package org.pdam.controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.PembayaranDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.dao.impl.PelangganDaoImplHibernate;
import org.pdam.dao.impl.PembayaranDaoImplHibernate;
import org.pdam.model.Akun;
import org.pdam.model.Pelanggan;
import org.pdam.model.Pembayaran;

public class PembayaranController implements Initializable
{

    @FXML
    private TableColumn<Pembayaran, Integer> IdTC;

    @FXML
    private TableColumn<Pembayaran, String> NamaTC;

    @FXML
    private TableColumn<Pembayaran, String> BankTC;

    @FXML
    private TableColumn<Pembayaran, String> TanggalTC;

    @FXML
    private TableColumn<Pembayaran, Integer> JumlahTC;

    @FXML
    private TextField namaAkunTF;

    @FXML
    private TextField namaBankTF;

    @FXML
    private DatePicker datepicker;

    @FXML
    private TextField jumlahTF;

    @FXML
    private TableView<Pembayaran> pembayaranTV;
   
    @FXML
    private Label akunLB;
    
    @FXML
    private Label invalidJumlahLB;
    
    private PembayaranDao pemDao;
    private PelangganDao pelDao;
    private AkunDao aDao;
    
    ObservableList<Pembayaran> data;
    
    public PembayaranController() 
    {
        aDao = new AkunDaoImplHibernate();
        pemDao = new PembayaranDaoImplHibernate();
        pembayaranTV = new TableView<>();
        pelDao = new PelangganDaoImplHibernate();
        datepicker = new DatePicker(LocalDate.now());
    }
    
    
    @FXML
    void konfirmasiBT(ActionEvent event)
    {   
        String namaAkun = namaAkunTF.getText();
        String namaBank = namaBankTF.getText();
        int jumlah = Integer.parseInt(jumlahTF.getText());
        String tanggal = datepicker.getValue().toString();
        
        String s = aDao.getAkunAktif().getUsername();
        Pelanggan pAktif = pelDao.getPelangganByUsername(s);
        
        if(jumlah==pAktif.getTagihan())
        {
            invalidJumlahLB.setVisible(false);
            Pembayaran pembayaran = new Pembayaran(pAktif.getNoVirtual(), namaAkun, namaBank, tanggal, pAktif.getIdRegional(), jumlah, pAktif.getIdPelanggan(), 0);
            System.out.println(pembayaran.getIdPembayaran());
            pemDao.savePembayaran(pembayaran);
            data.add(pembayaran);
            inisialisasiInputan();
        }
        else
        {
            invalidJumlahLB.setVisible(true);
        }
        
    }

    public void loadData()
    {
        Pelanggan pAktif = pelDao.getPelangganByUsername(aDao.getAkunAktif().getUsername());
        List<Pembayaran> pembayarans = pemDao.getAllBelumVerfikasi(pAktif.getIdPelanggan());
        data = FXCollections.observableArrayList(pembayarans);
        IdTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,Integer>("idPembayaran"));
        NamaTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("nama"));
        BankTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("namaBank"));
        TanggalTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("tanggalTransfer"));
        JumlahTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,Integer>("jumlah"));
        
        pembayaranTV.setItems(data);
        
        akunLB.setText(aDao.getAkunAktif().getUsername());
    }

    @FXML
    void logoutBT(ActionEvent event) throws IOException 
    {
        Akun a = aDao.getAkunAktif();
        System.out.println("awal "+a.getId());
        a.setId(0);
        aDao.updateIDAkun(a);
        System.out.println("akhir "+a.getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void tentangAkunBT(ActionEvent event) throws IOException 
    {
        
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/AkunPelanggan.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }
    
    public void inisialisasiInputan()
    {
        namaAkunTF.setText("");
        namaBankTF.setText("");
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) 
    {
        loadData();
    }

    

}
