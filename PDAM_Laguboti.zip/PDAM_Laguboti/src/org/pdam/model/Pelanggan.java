/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pdam.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author helkia
 */
@Entity
@Table(name = "pelanggan")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pelanggan.findAll", query = "SELECT p FROM Pelanggan p"),
    @NamedQuery(name = "Pelanggan.findByIdPelanggan", query = "SELECT p FROM Pelanggan p WHERE p.idPelanggan = :idPelanggan"),
    @NamedQuery(name = "Pelanggan.findByUsername", query = "SELECT p FROM Pelanggan p WHERE p.username = :username"),
    @NamedQuery(name = "Pelanggan.findByNamaPelanggan", query = "SELECT p FROM Pelanggan p WHERE p.namaPelanggan = :namaPelanggan"),
    @NamedQuery(name = "Pelanggan.findByAlamat", query = "SELECT p FROM Pelanggan p WHERE p.alamat = :alamat"),
    @NamedQuery(name = "Pelanggan.findByPekerjaan", query = "SELECT p FROM Pelanggan p WHERE p.pekerjaan = :pekerjaan"),
    @NamedQuery(name = "Pelanggan.findByTagihan", query = "SELECT p FROM Pelanggan p WHERE p.tagihan = :tagihan"),
    @NamedQuery(name = "Pelanggan.findByIdRegional", query = "SELECT p FROM Pelanggan p WHERE p.idRegional = :idRegional"),
    @NamedQuery(name = "Pelanggan.findByNoTelepon", query = "SELECT p FROM Pelanggan p WHERE p.noTelepon = :noTelepon"),
    @NamedQuery(name = "Pelanggan.findByPassword", query = "SELECT p FROM Pelanggan p WHERE p.password = :password"),
    @NamedQuery(name = "Pelanggan.findByNoVirtual", query = "SELECT p FROM Pelanggan p WHERE p.noVirtual = :noVirtual")})
public class Pelanggan implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_pelanggan")
    private Integer idPelanggan;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "nama_pelanggan")
    private String namaPelanggan;
    @Basic(optional = false)
    @Column(name = "alamat")
    private String alamat;
    @Basic(optional = false)
    @Column(name = "pekerjaan")
    private String pekerjaan;
    @Basic(optional = false)
    @Column(name = "tagihan")
    private int tagihan;
    @Basic(optional = false)
    @Column(name = "id_regional")
    private int idRegional;
    @Basic(optional = false)
    @Column(name = "no_telepon")
    private long noTelepon;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "no_virtual")
    private int noVirtual;

    public Pelanggan() {
    }

    public Pelanggan(Integer idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public Pelanggan(Integer idPelanggan, String username, String namaPelanggan, String alamat, String pekerjaan, int tagihan, int idRegional, long noTelepon, String password, int noVirtual) {
        this.idPelanggan = idPelanggan;
        this.username = username;
        this.namaPelanggan = namaPelanggan;
        this.alamat = alamat;
        this.pekerjaan = pekerjaan;
        this.tagihan = tagihan;
        this.idRegional = idRegional;
        this.noTelepon = noTelepon;
        this.password = password;
        this.noVirtual = noVirtual;
    }

    public Integer getIdPelanggan() {
        return idPelanggan;
    }

    public void setIdPelanggan(Integer idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getPekerjaan() {
        return pekerjaan;
    }

    public void setPekerjaan(String pekerjaan) {
        this.pekerjaan = pekerjaan;
    }

    public int getTagihan() {
        return tagihan;
    }

    public void setTagihan(int tagihan) {
        this.tagihan = tagihan;
    }

    public int getIdRegional() {
        return idRegional;
    }

    public void setIdRegional(int idRegional) {
        this.idRegional = idRegional;
    }

    public long getNoTelepon() {
        return noTelepon;
    }

    public void setNoTelepon(long noTelepon) {
        this.noTelepon = noTelepon;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getNoVirtual() {
        return noVirtual;
    }

    public void setNoVirtual(int noVirtual) {
        this.noVirtual = noVirtual;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPelanggan != null ? idPelanggan.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pelanggan)) {
            return false;
        }
        Pelanggan other = (Pelanggan) object;
        if ((this.idPelanggan == null && other.idPelanggan != null) || (this.idPelanggan != null && !this.idPelanggan.equals(other.idPelanggan))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.pdam.model.Pelanggan[ idPelanggan=" + idPelanggan + " ]";
    }
    
}
