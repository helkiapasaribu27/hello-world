/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pdam.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author helkia
 */
@Entity
@Table(name = "pegawai")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pegawai.findAll", query = "SELECT p FROM Pegawai p"),
    @NamedQuery(name = "Pegawai.findByIdPegawai", query = "SELECT p FROM Pegawai p WHERE p.idPegawai = :idPegawai"),
    @NamedQuery(name = "Pegawai.findByUsername", query = "SELECT p FROM Pegawai p WHERE p.username = :username"),
    @NamedQuery(name = "Pegawai.findByPassword", query = "SELECT p FROM Pegawai p WHERE p.password = :password"),
    @NamedQuery(name = "Pegawai.findByNamaPegawai", query = "SELECT p FROM Pegawai p WHERE p.namaPegawai = :namaPegawai"),
    @NamedQuery(name = "Pegawai.findByAlamat", query = "SELECT p FROM Pegawai p WHERE p.alamat = :alamat"),
    @NamedQuery(name = "Pegawai.findByNoTelepon", query = "SELECT p FROM Pegawai p WHERE p.noTelepon = :noTelepon"),
    @NamedQuery(name = "Pegawai.findByIdRegional", query = "SELECT p FROM Pegawai p WHERE p.idRegional = :idRegional"),
    @NamedQuery(name = "Pegawai.findByTahunMasuk", query = "SELECT p FROM Pegawai p WHERE p.tahunMasuk = :tahunMasuk"),
    @NamedQuery(name = "Pegawai.findByIdJabatan", query = "SELECT p FROM Pegawai p WHERE p.idJabatan = :idJabatan")})
public class Pegawai implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_pegawai")
    private Integer idPegawai;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "nama_pegawai")
    private String namaPegawai;
    @Basic(optional = false)
    @Column(name = "alamat")
    private String alamat;
    @Basic(optional = false)
    @Column(name = "no_telepon")
    private int noTelepon;
    @Basic(optional = false)
    @Column(name = "id_regional")
    private int idRegional;
    @Basic(optional = false)
    @Column(name = "tahun_masuk")
    private int tahunMasuk;
    @Basic(optional = false)
    @Column(name = "id_jabatan")
    private int idJabatan;

    public Pegawai() {
    }

    public Pegawai(Integer idPegawai) {
        this.idPegawai = idPegawai;
    }

    public Pegawai(Integer idPegawai, String username, String password, String namaPegawai, String alamat, int noTelepon, int idRegional, int tahunMasuk, int idJabatan) {
        this.idPegawai = idPegawai;
        this.username = username;
        this.password = password;
        this.namaPegawai = namaPegawai;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.idRegional = idRegional;
        this.tahunMasuk = tahunMasuk;
        this.idJabatan = idJabatan;
    }

    public Integer getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(Integer idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNamaPegawai() {
        return namaPegawai;
    }

    public void setNamaPegawai(String namaPegawai) {
        this.namaPegawai = namaPegawai;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public int getNoTelepon() {
        return noTelepon;
    }

    public void setNoTelepon(int noTelepon) {
        this.noTelepon = noTelepon;
    }

    public int getIdRegional() {
        return idRegional;
    }

    public void setIdRegional(int idRegional) {
        this.idRegional = idRegional;
    }

    public int getTahunMasuk() {
        return tahunMasuk;
    }

    public void setTahunMasuk(int tahunMasuk) {
        this.tahunMasuk = tahunMasuk;
    }

    public int getIdJabatan() {
        return idJabatan;
    }

    public void setIdJabatan(int idJabatan) {
        this.idJabatan = idJabatan;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPegawai != null ? idPegawai.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pegawai)) {
            return false;
        }
        Pegawai other = (Pegawai) object;
        if ((this.idPegawai == null && other.idPegawai != null) || (this.idPegawai != null && !this.idPegawai.equals(other.idPegawai))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.pdam.model.Pegawai[ idPegawai=" + idPegawai + " ]";
    }
    
}
